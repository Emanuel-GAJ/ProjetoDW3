// Importação das funções de conexão, upload e listagem de arquivos.
import { verifyConnection, uploadFile, listFiles } from "../utilities/scp.js";

// Importação do repositorio de arquivos.
import { createFile, findFileByUuid, findAllFiles } from "../repositories/fileRepository.js";

export const connection = async (req, res) => {
    try {
        const response = await verifyConnection();
        res.status(200).send(response);
    } catch (error) {
        res.status(500).send({ message: "Erro ao conectar!" });
    }
}

export const upload = async (req, res) => {


    // Pega o destino do arquivo.
    const destination = `/home/${process.env.SCP_USERNAME}/`;

    try {

        // Pega o arquivo enviado pelo usuário.
        const { file } = req.body;

        console.log(file);

        // Pega o uuid do usuário.
        const { uuid } = req.user;
        console.log(uuid);

        await uploadFile(file, destination);

        const dataFile = {
            filename: file.name,
            type: file.type,
            size: file.size,
            remotePath: destination,
            status: "Enviado",
            userUUID: uuid,
        }

        await createFile(dataFile);

        res.status(200).send({ message: "Arquivo enviado com sucesso!" });
    } catch (error) {

        // Pega o uuid do usuário.
        const { uuid } = req.user;

        // Pega o arquivo enviado pelo usuário.
        const file = req.body;

        const dataFile = {
            filename: file.name,
            type: file.type,
            size: file.size,
            remotePath: destination,
            status: "Falha ao enviar",
            userUUID: uuid,
        }

        await createFile(dataFile);

        res.status(500).send({ message: "Erro ao enviar arquivo!" });
    }
}

export const list = async (req, res) => {
    try {
        const response = await listFiles();
        res.status(200).send(response);
    } catch (error) {
        res.status(500).send({ message: "Erro ao listar arquivos!" });
    }
}
