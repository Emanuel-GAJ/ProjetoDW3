import jwt from "jsonwebtoken";

export const isAuthenticated = async (req, res, next) => {
    try {
        const { authorization } = req.headers;

        const [, token] = authorization.split(" ");

        const { uuid, username } = jwt.verify(
            token,
            process.env.API_TOKEN_SECRET
        );

        req.user = {
            uuid,
            username,
        };

        return next();
    } catch (error) {
        console.log(error);
        return res.status(401).json({
            message: "Token inválido.",
        });
    }
};
