import Auth from './auth.js';

// Array de Objetos de arquivos.
let dataFiles = [];

// Input[type=file] do formulário.
const inputFiles = document.querySelector('input#formFile');

// Botão de adicionar arquivos.
const btnAddFiles = document.querySelector('button#addfiles');

// Botão de enviar arquivos.
const btnSendFiles = document.querySelector('button#sendfiles');

// Corpo da tabela de arquivos.
const tableBody = document.querySelector('tbody#tbodyFiles');

// Adicionar arquivos selecionados ao array de arquivos.
inputFiles.addEventListener('change', (event) => {
    dataFiles = [...dataFiles, ...event.target.files];
});


// Evento de click do botão de adicionar arquivos.
btnAddFiles.addEventListener('click', (event) => {
    event.preventDefault();

    addFilesToTable();

    // Limpa o input[type=file].
    inputFiles.value = '';

});


// Adicionar arquivos selecionados na tabela de arquivos.
const addFilesToTable = () => {
    tableBody.innerHTML = '';

    dataFiles.forEach((file, index) => {
        const tr = document.createElement('tr');
        const tdIndex = document.createElement('td');
        const tdName = document.createElement('td');
        const tdSize = document.createElement('td');
        const tdType = document.createElement('td');
        const tdModified = document.createElement('td');

        tdIndex.textContent = index + 1;
        tdName.textContent = file.name;
        tdSize.textContent = file.size;
        tdType.textContent = file.type;
        tdModified.textContent = file.lastModified;

        tr.appendChild(tdIndex);
        tr.appendChild(tdName);
        tr.appendChild(tdSize);
        tr.appendChild(tdType);
        tr.appendChild(tdModified);

        tableBody.appendChild(tr);
    });

}

// Função para enviar os arquivos selecionados.
const sendFiles = async () => {

    // Envia a requisição para cada arquivo.
    dataFiles.forEach(async (file, index) => {
        console.log(file);
        const response = await fetch('/files/upload', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${Auth.getToken()}`
            },

            // Converte o arquivo para JSON.
            body: JSON.stringify({
                file,
            })
        });

        // Se o status da resposta for 200, então o arquivo foi enviado com sucesso.
        if (response.status === 200) {
            // Adiciona um icone de sucesso na tabela de arquivos.
            const tdStatus = document.createElement('td');
            tdStatus.innerHTML = '<i class="fas fa-check-circle text-success"></i>';
            tableBody.children[index].appendChild(tdStatus);
        } else {
            // Adiciona um icone de erro na tabela de arquivos.
            const tdStatus = document.createElement('td');
            tdStatus.innerHTML = '<i class="fas fa-times-circle text-danger"></i>';
            tableBody.children[index].appendChild(tdStatus);
        }

    });
}




// Verifica se o usuário está logado, antes de carregar a página.
if (Auth.isAuthenticated()) {
    Auth.setUser();
    Auth.logout();


    // Evento de click do botão de enviar arquivos.
    btnSendFiles.addEventListener('click', (event) => {
        event.preventDefault();

        sendFiles();
    });


}
