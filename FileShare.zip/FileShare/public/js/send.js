import Auth from './auth.js';

// Função para montar tabela  com path recebido. (POST-> /files/list)
const mountTable = () => {

    // Botão search para pesquisar o path.
    const searchButton = document.querySelector('#button-search');

    // evento de click no botão search.
    searchButton.addEventListener('click', async () => {
        // Pega o elemento com id="file-table-body".
        const fileTableBody = document.getElementById("file-table-body");

        // Input para o path.
        const pathInput = document.querySelector('.input-group input');

        console.log(pathInput.value);

        // Faz a requisição para o servidor.
        const response = fetch('/local/files', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                Authorization: `Bearer ${Auth.getToken()}`,
            },

            // Passa o path para o servidor.
            body: JSON.stringify({
                path: pathInput.value,
            }),
        })
            .then((response) => response.json())
            .then((data) => {
                // Limpa a tabela.
                fileTableBody.innerHTML = '';

                // Percorre o array de arquivos.
                data.forEach((file) => {
                    // icone para o tipo de arquivo.
                    let icon = '';

                    // Verifica o tipo de arquivo.
                    if (file.type === 'directory') {
                        icon = '<i class="fas fa-folder"></i>';
                    } else {
                        icon = '<i class="fas fa-file"></i>';
                    }


                    // monta a tabela.
                    fileTableBody.innerHTML += `
                    <tr>
                        <td>${file.name}</td>
                        <td>${icon}</td>
                        <td>${file.size}</td>
                        <td>${file.date}</td>
                        <td>
                            <a href="/local/files/${file.name}" target="_blank">
                                <i class="fas fa-download"></i>
                            </a>
                        </td>
                    </tr>
                    `;

                });
            });

    });
}




// Verifica se o usuário está logado, antes de carregar a página.
if (Auth.isAuthenticated()) {
    Auth.setUser();
    Auth.logout();

    mountTable();


}
